import React from 'react'
import './header.css'
const SecondHeader = () => {
  return (
    <div>
        <div className="container-second">
    </div>
    </div>
  )
}

export default SecondHeader