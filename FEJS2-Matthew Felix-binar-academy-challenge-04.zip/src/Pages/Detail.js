import React from 'react'
import SecondHeader from '../Components/Header/SecondHeader'
import SecondSearch from '../Components/SearchBar/SecondSearch'


const Detail = () => {
    return (
        <>
          <SecondHeader/>
          <SecondSearch/>

        </>
      )
}

export default Detail